README POUR LANCER LE PROJET :

-Installez vos dependances symfony
-Modifiez le env.local (optionnel)
-Allez sur phpmyadmin (ou autre) pour integrer la base de données
- Faites npm install
-Lancez le serveur symfony 
- Lancer le serveur Encore : npm run dev-server
-Ouvrez uniquement le lien localHost symfony (port:8000)

